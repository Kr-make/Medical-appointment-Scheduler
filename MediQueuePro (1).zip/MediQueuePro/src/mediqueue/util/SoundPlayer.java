package mediqueue.util;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.awt.Toolkit;

/**
 * Generates a short notification tone at runtime using the Java Sound API,
 * so the project does not depend on any bundled audio files.
 */
public class SoundPlayer {

    public static void playNotification() {
        new Thread(() -> {
            try {
                float sampleRate = 44100;
                AudioFormat format = new AudioFormat(sampleRate, 8, 1, true, false);
                SourceDataLine line = AudioSystem.getSourceDataLine(format);
                line.open(format);
                line.start();

                byte[] buf = new byte[1];
                for (int i = 0; i < 8000; i++) {
                    double angle = i / (sampleRate / 880.0) * 2.0 * Math.PI;
                    buf[0] = (byte) (Math.sin(angle) * 100);
                    line.write(buf, 0, 1);
                }
                line.drain();
                line.close();
            } catch (Exception e) {
                Toolkit.getDefaultToolkit().beep();
            }
        }).start();
    }
}
