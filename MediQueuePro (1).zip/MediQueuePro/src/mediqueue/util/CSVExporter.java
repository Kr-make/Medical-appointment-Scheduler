package mediqueue.util;

import mediqueue.model.Patient;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class CSVExporter {

    public static void export(List<Patient> patients, String filePath) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filePath))) {
            pw.println("ID,Token,Name,Age,Gender,Department,Doctor,Priority,Status,Time,Symptoms");
            for (Patient p : patients) {
                pw.printf("%s,%d,%s,%d,%s,%s,%s,%s,%s,%s,%s%n",
                        p.getId(), p.getToken(), esc(p.getName()), p.getAge(), p.getGender(),
                        esc(p.getDepartment()), esc(p.getDoctor()), p.getPriority(), p.getStatus(),
                        p.getRegisteredTimeString(), esc(p.getSymptoms()));
            }
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace(",", ";");
    }
}
