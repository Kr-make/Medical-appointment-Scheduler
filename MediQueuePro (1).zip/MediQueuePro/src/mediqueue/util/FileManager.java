package mediqueue.util;

import mediqueue.model.Doctor;
import mediqueue.model.Patient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Handles offline data storage using Java Object Serialization,
 * plus a small properties file for user settings.
 */
public class FileManager {

    private static final String DATA_DIR = "data";
    private static final String PATIENTS_FILE = DATA_DIR + "/patients.dat";
    private static final String DOCTORS_FILE = DATA_DIR + "/doctors.dat";
    private static final String SETTINGS_FILE = DATA_DIR + "/settings.properties";

    static {
        new File(DATA_DIR).mkdirs();
    }

    @SuppressWarnings("unchecked")
    public static List<Patient> loadPatients() {
        File f = new File(PATIENTS_FILE);
        if (!f.exists()) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
            return (List<Patient>) in.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public static void savePatients(List<Patient> patients) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(PATIENTS_FILE))) {
            out.writeObject(patients);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Doctor> loadDoctors() {
        File f = new File(DOCTORS_FILE);
        if (!f.exists()) return defaultDoctors();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
            return (List<Doctor>) in.readObject();
        } catch (Exception e) {
            return defaultDoctors();
        }
    }

    public static void saveDoctors(List<Doctor> doctors) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(DOCTORS_FILE))) {
            out.writeObject(doctors);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static List<Doctor> defaultDoctors() {
        List<Doctor> list = new ArrayList<>();
        list.add(new Doctor("Aarav Sharma", "General Medicine", true));
        list.add(new Doctor("Priya Verma", "Pediatrics", true));
        list.add(new Doctor("Rohan Gupta", "Orthopedics", false));
        list.add(new Doctor("Sneha Iyer", "Cardiology", true));
        list.add(new Doctor("Karan Mehta", "ENT", true));
        return list;
    }

    public static Properties loadSettings() {
        Properties p = new Properties();
        File f = new File(SETTINGS_FILE);
        if (f.exists()) {
            try (FileInputStream in = new FileInputStream(f)) {
                p.load(in);
            } catch (Exception ignored) {
            }
        }
        p.putIfAbsent("theme", "light");
        p.putIfAbsent("consultationMinutes", "10");
        return p;
    }

    public static void saveSettings(Properties p) {
        try (FileOutputStream out = new FileOutputStream(SETTINGS_FILE)) {
            p.store(out, "MediQueue Pro Settings");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
