package mediqueue.util;

import java.awt.Color;

public class ThemeManager {

    private static boolean dark = false;

    public static boolean isDark() { return dark; }
    public static void setDark(boolean d) { dark = d; }

    public static Color background() { return dark ? new Color(30, 33, 40) : new Color(245, 247, 250); }
    public static Color panelBg() { return dark ? new Color(40, 44, 52) : Color.WHITE; }
    public static Color sidebarBg() { return dark ? new Color(24, 26, 32) : new Color(33, 42, 58); }
    public static Color accent() { return new Color(41, 128, 185); }
    public static Color textPrimary() { return dark ? Color.WHITE : new Color(33, 37, 41); }
    public static Color textSecondary() { return dark ? new Color(180, 180, 180) : new Color(108, 117, 125); }
    public static Color success() { return new Color(39, 174, 96); }
    public static Color danger() { return new Color(231, 76, 60); }
    public static Color warning() { return new Color(243, 156, 18); }
}
