package mediqueue.util;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * A tiny, dependency-free PDF writer. It builds a single-page PDF document
 * by hand using raw PDF syntax (objects, xref table, trailer). This avoids
 * needing an external library such as Apache PDFBox while still producing
 * a valid, openable PDF file - useful as a classroom demonstration of how
 * the PDF file format is structured.
 */
public class PDFExporter {

    public static void export(String title, List<String> lines, String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        content.append("BT /F1 16 Tf 50 780 Td (").append(escape(title)).append(") Tj ET\n");
        content.append("BT /F1 11 Tf\n");

        int y = 750;
        for (String line : lines) {
            content.append("1 0 0 1 50 ").append(y).append(" Tm (").append(escape(line)).append(") Tj\n");
            y -= 18;
            if (y < 40) break; // single page demo
        }
        content.append("ET\n");

        byte[] contentBytes = content.toString().getBytes(StandardCharsets.ISO_8859_1);

        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            List<Integer> offsets = new ArrayList<>();
            String header = "%PDF-1.4\n";
            fos.write(header.getBytes(StandardCharsets.ISO_8859_1));
            int pos = header.length();

            String obj1 = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
            offsets.add(pos);
            fos.write(obj1.getBytes(StandardCharsets.ISO_8859_1));
            pos += obj1.length();

            String obj2 = "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
            offsets.add(pos);
            fos.write(obj2.getBytes(StandardCharsets.ISO_8859_1));
            pos += obj2.length();

            String obj3 = "3 0 obj\n<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 5 0 R >> >> "
                    + "/MediaBox [0 0 612 792] /Contents 4 0 R >>\nendobj\n";
            offsets.add(pos);
            fos.write(obj3.getBytes(StandardCharsets.ISO_8859_1));
            pos += obj3.length();

            String obj4Header = "4 0 obj\n<< /Length " + contentBytes.length + " >>\nstream\n";
            String obj4Footer = "\nendstream\nendobj\n";
            offsets.add(pos);
            fos.write(obj4Header.getBytes(StandardCharsets.ISO_8859_1));
            fos.write(contentBytes);
            fos.write(obj4Footer.getBytes(StandardCharsets.ISO_8859_1));
            pos += obj4Header.length() + contentBytes.length + obj4Footer.length();

            String obj5 = "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
            offsets.add(pos);
            fos.write(obj5.getBytes(StandardCharsets.ISO_8859_1));
            pos += obj5.length();

            int xrefStart = pos;
            StringBuilder xref = new StringBuilder();
            xref.append("xref\n0 ").append(offsets.size() + 1).append("\n");
            xref.append("0000000000 65535 f \n");
            for (int off : offsets) {
                xref.append(String.format("%010d 00000 n \n", off));
            }
            xref.append("trailer\n<< /Size ").append(offsets.size() + 1).append(" /Root 1 0 R >>\n");
            xref.append("startxref\n").append(xrefStart).append("\n%%EOF");
            fos.write(xref.toString().getBytes(StandardCharsets.ISO_8859_1));
        }
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
    }
}
