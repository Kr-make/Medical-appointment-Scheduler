package mediqueue.model;

import java.io.Serializable;

public class Doctor implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String name;
    private final String department;
    private boolean available;

    public Doctor(String name, String department, boolean available) {
        this.name = name;
        this.department = department;
        this.available = available;
    }

    public String getName() { return name; }
    public String getDepartment() { return department; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return "Dr. " + name + " (" + department + ")";
    }
}
