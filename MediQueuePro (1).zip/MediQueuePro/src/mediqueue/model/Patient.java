package mediqueue.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Patient implements Serializable, Comparable<Patient> {
    private static final long serialVersionUID = 1L;

    public enum Priority { NORMAL, EMERGENCY }
    public enum Status { WAITING, CALLED, DONE, SKIPPED }

    private final String id;
    private final int token;
    private final String name;
    private final int age;
    private final String gender;
    private final String department;
    private final String doctor;
    private final Priority priority;
    private final String symptoms;
    private final String photoPath;
    private final LocalDateTime registeredAt;
    private Status status;

    public Patient(String id, int token, String name, int age, String gender,
                   String department, String doctor, Priority priority,
                   String symptoms, String photoPath) {
        this.id = id;
        this.token = token;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.doctor = doctor;
        this.priority = priority;
        this.symptoms = symptoms;
        this.photoPath = photoPath;
        this.registeredAt = LocalDateTime.now();
        this.status = Status.WAITING;
    }

    public String getId() { return id; }
    public int getToken() { return token; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getGender() { return gender; }
    public String getDepartment() { return department; }
    public String getDoctor() { return doctor; }
    public Priority getPriority() { return priority; }
    public String getSymptoms() { return symptoms; }
    public String getPhotoPath() { return photoPath; }
    public LocalDateTime getRegisteredAt() { return registeredAt; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public String getRegisteredTimeString() {
        return registeredAt.format(DateTimeFormatter.ofPattern("hh:mm:ss a"));
    }

    public String getRegisteredDateString() {
        return registeredAt.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
    }

    @Override
    public int compareTo(Patient other) {
        return this.registeredAt.compareTo(other.registeredAt);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Patient)) return false;
        return id.equals(((Patient) o).id);
    }

    @Override
    public int hashCode() { return id.hashCode(); }

    @Override
    public String toString() {
        return "Token #" + token + " - " + name;
    }
}
