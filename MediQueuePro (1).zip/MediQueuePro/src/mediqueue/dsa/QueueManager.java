package mediqueue.dsa;

import mediqueue.model.Patient;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Stack;

/**
 * Core data-structure engine of the application.
 * Demonstrates: Queue (LinkedList), PriorityQueue, Stack, and simple
 * waiting-time estimation logic.
 */
public class QueueManager {

    private final LinkedList<Patient> normalQueue = new LinkedList<>();
    private final PriorityQueue<Patient> emergencyQueue = new PriorityQueue<>();
    private final Stack<Patient> calledHistory = new Stack<>();
    private Patient lastCalled = null;

    public void enqueue(Patient p) {
        if (p.getPriority() == Patient.Priority.EMERGENCY) {
            emergencyQueue.add(p);
        } else {
            normalQueue.add(p);
        }
    }

    public Patient callNext() {
        Patient next;
        if (!emergencyQueue.isEmpty()) {
            next = emergencyQueue.poll();
        } else {
            next = normalQueue.poll();
        }
        if (next != null) {
            next.setStatus(Patient.Status.CALLED);
            calledHistory.push(next);
            lastCalled = next;
        }
        return next;
    }

    public void skip(Patient p) {
        if (emergencyQueue.remove(p) || normalQueue.remove(p)) {
            p.setStatus(Patient.Status.SKIPPED);
            normalQueue.addLast(p);
        }
    }

    public Patient undoLastCall() {
        if (calledHistory.isEmpty()) return null;
        Patient p = calledHistory.pop();
        p.setStatus(Patient.Status.WAITING);
        enqueue(p);
        lastCalled = calledHistory.isEmpty() ? null : calledHistory.peek();
        return p;
    }

    public int estimateWaitMinutes(Patient p, int consultationMinutes) {
        int position;
        if (p.getPriority() == Patient.Priority.EMERGENCY) {
            position = new ArrayList<>(emergencyQueue).indexOf(p);
        } else {
            position = emergencyQueue.size() + normalQueue.indexOf(p);
        }
        return Math.max(0, position) * consultationMinutes;
    }

    public List<Patient> getAllWaiting() {
        List<Patient> all = new ArrayList<>();
        all.addAll(emergencyQueue);
        all.addAll(normalQueue);
        return all;
    }

    public int totalWaiting() { return emergencyQueue.size() + normalQueue.size(); }
    public int emergencyCount() { return emergencyQueue.size(); }
    public Patient getLastCalled() { return lastCalled; }
}
