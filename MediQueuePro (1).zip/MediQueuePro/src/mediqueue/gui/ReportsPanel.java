package mediqueue.gui;

import mediqueue.model.Patient;
import mediqueue.util.CSVExporter;
import mediqueue.util.PDFExporter;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ReportsPanel extends JPanel {

    private final MainFrame frame;
    private final JLabel totalLabel, emergencyLabel, avgWaitLabel, busiestLabel;
    private final ChartPanel chartPanel;

    public ReportsPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel header = new JLabel("Reports & Statistics");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        JPanel statsRow = new JPanel(new GridLayout(1, 4, 10, 10));
        totalLabel = new JLabel("0", SwingConstants.CENTER);
        emergencyLabel = new JLabel("0", SwingConstants.CENTER);
        avgWaitLabel = new JLabel("0", SwingConstants.CENTER);
        busiestLabel = new JLabel("-", SwingConstants.CENTER);

        statsRow.add(statBox("Today's Patients", totalLabel));
        statsRow.add(statBox("Emergency Cases", emergencyLabel));
        statsRow.add(statBox("Avg Waiting Time", avgWaitLabel));
        statsRow.add(statBox("Busiest Department", busiestLabel));

        chartPanel = new ChartPanel();
        chartPanel.setPreferredSize(new Dimension(100, 300));
        chartPanel.setBorder(BorderFactory.createTitledBorder("Patients by Department"));

        JPanel center = new JPanel(new BorderLayout(10, 10));
        center.add(statsRow, BorderLayout.NORTH);
        center.add(chartPanel, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        JPanel exportRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton pdfBtn = new JButton("Export PDF Report");
        JButton csvBtn = new JButton("Export CSV");
        pdfBtn.addActionListener(e -> exportPDF());
        csvBtn.addActionListener(e -> exportCSV());
        exportRow.add(pdfBtn);
        exportRow.add(csvBtn);
        add(exportRow, BorderLayout.SOUTH);
    }

    private JPanel statBox(String title, JLabel valueLabel) {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createTitledBorder(title));
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        p.add(valueLabel, BorderLayout.CENTER);
        return p;
    }

    public void refresh() {
        List<Patient> all = new ArrayList<>(frame.getPatientMap().values());
        LocalDate today = LocalDate.now();
        List<Patient> todays = all.stream()
                .filter(p -> p.getRegisteredAt().toLocalDate().equals(today))
                .toList();

        totalLabel.setText(String.valueOf(todays.size()));
        long emergencyCount = todays.stream().filter(p -> p.getPriority() == Patient.Priority.EMERGENCY).count();
        emergencyLabel.setText(String.valueOf(emergencyCount));

        int consultMin = Integer.parseInt(frame.getSettings().getProperty("consultationMinutes", "10"));
        double avgWait = frame.getQueueManager().getAllWaiting().stream()
                .mapToInt(p -> frame.getQueueManager().estimateWaitMinutes(p, consultMin))
                .average().orElse(0);
        avgWaitLabel.setText(String.format("%.0f min", avgWait));

        Map<String, Long> byDept = new TreeMap<>();
        for (Patient p : todays) {
            byDept.merge(p.getDepartment(), 1L, Long::sum);
        }
        String busiest = byDept.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("-");
        busiestLabel.setText(busiest);

        chartPanel.setData(byDept);
    }

    private void exportPDF() {
        try {
            new File("data").mkdirs();
            List<String> lines = new ArrayList<>();
            lines.add("Generated: " + java.time.LocalDateTime.now());
            lines.add("Today's Patients: " + totalLabel.getText());
            lines.add("Emergency Cases: " + emergencyLabel.getText());
            lines.add("Average Waiting Time: " + avgWaitLabel.getText());
            lines.add("Busiest Department: " + busiestLabel.getText());
            lines.add("");
            lines.add("Patient List:");
            for (Patient p : frame.getPatientMap().values()) {
                lines.add("#" + p.getToken() + " " + p.getName() + " - " + p.getDepartment() + " - " + p.getStatus());
            }
            String path = "data/report_" + System.currentTimeMillis() + ".pdf";
            PDFExporter.export("MediQueue Pro - Daily Report", lines, path);
            JOptionPane.showMessageDialog(this, "PDF report saved to: " + path);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage());
        }
    }

    private void exportCSV() {
        try {
            new File("data").mkdirs();
            String path = "data/patients_" + System.currentTimeMillis() + ".csv";
            CSVExporter.export(new ArrayList<>(frame.getPatientMap().values()), path);
            JOptionPane.showMessageDialog(this, "CSV exported to: " + path);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage());
        }
    }
}
