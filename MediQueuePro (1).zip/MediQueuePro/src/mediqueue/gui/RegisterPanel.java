package mediqueue.gui;

import mediqueue.model.Doctor;
import mediqueue.model.Patient;
import mediqueue.util.SoundPlayer;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class RegisterPanel extends JPanel {

    private final MainFrame frame;
    private JTextField nameField, ageField, symptomsField;
    private JComboBox<String> genderBox, departmentBox, priorityBox;
    private JComboBox<Doctor> doctorBox;
    private JLabel photoLabel;
    private String photoPath = null;

    private static final String[] DEPARTMENTS = {"General Medicine", "Pediatrics", "Orthopedics", "Cardiology", "ENT"};

    public RegisterPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;
        JLabel header = new JLabel("Patient Registration");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        c.gridx = 0; c.gridy = row; c.gridwidth = 2; add(header, c); row++;
        c.gridwidth = 1;

        nameField = new JTextField(20);
        ageField = new JTextField(20);
        symptomsField = new JTextField(20);
        genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        departmentBox = new JComboBox<>(DEPARTMENTS);
        doctorBox = new JComboBox<>();
        priorityBox = new JComboBox<>(new String[]{"NORMAL", "EMERGENCY"});

        departmentBox.addActionListener(e -> updateDoctors());

        row = addRow(c, row, "Full Name:", nameField);
        row = addRow(c, row, "Age:", ageField);
        row = addRow(c, row, "Gender:", genderBox);
        row = addRow(c, row, "Department:", departmentBox);
        row = addRow(c, row, "Doctor:", doctorBox);
        row = addRow(c, row, "Priority:", priorityBox);
        row = addRow(c, row, "Symptoms:", symptomsField);

        JButton photoBtn = new JButton("Choose Photo (optional)");
        photoLabel = new JLabel("No photo selected");
        photoBtn.addActionListener(e -> choosePhoto());
        c.gridx = 0; c.gridy = row; add(photoBtn, c);
        c.gridx = 1; c.gridy = row; add(photoLabel, c); row++;

        JButton submitBtn = new JButton("Register & Add to Queue");
        submitBtn.setBackground(new Color(41, 128, 185));
        submitBtn.setForeground(Color.WHITE);
        submitBtn.addActionListener(e -> submit());
        c.gridx = 0; c.gridy = row; c.gridwidth = 2; add(submitBtn, c);

        updateDoctors();
    }

    private int addRow(GridBagConstraints c, int row, String label, Component field) {
        c.gridx = 0; c.gridy = row; add(new JLabel(label), c);
        c.gridx = 1; c.gridy = row; add(field, c);
        return row + 1;
    }

    private void updateDoctors() {
        doctorBox.removeAllItems();
        String dept = (String) departmentBox.getSelectedItem();
        for (Doctor d : frame.getDoctors()) {
            if (d.getDepartment().equals(dept)) doctorBox.addItem(d);
        }
    }

    private void choosePhoto() {
        JFileChooser fc = new JFileChooser();
        int res = fc.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            photoPath = f.getAbsolutePath();
            photoLabel.setText(f.getName());
        }
    }

    private void submit() {
        String name = nameField.getText().trim();
        String ageStr = ageField.getText().trim();
        if (name.isEmpty() || ageStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in name and age.", "Missing Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int age;
        try {
            age = Integer.parseInt(ageStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Age must be a number.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Doctor doctor = (Doctor) doctorBox.getSelectedItem();
        if (doctor == null) {
            JOptionPane.showMessageDialog(this, "No doctor available in this department.", "Missing Doctor", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int token = frame.nextToken();
        String id = "PT" + String.format("%04d", token);
        Patient.Priority priority = "EMERGENCY".equals(priorityBox.getSelectedItem())
                ? Patient.Priority.EMERGENCY : Patient.Priority.NORMAL;

        Patient p = new Patient(id, token, name, age, (String) genderBox.getSelectedItem(),
                (String) departmentBox.getSelectedItem(), doctor.toString(), priority,
                symptomsField.getText().trim(), photoPath);

        frame.getPatientMap().put(id, p);
        frame.getQueueManager().enqueue(p);
        SoundPlayer.playNotification();
        frame.refreshAll();

        JOptionPane.showMessageDialog(this, "Patient registered!\nToken Number: " + token, "Success", JOptionPane.INFORMATION_MESSAGE);

        nameField.setText("");
        ageField.setText("");
        symptomsField.setText("");
        photoPath = null;
        photoLabel.setText("No photo selected");
        frame.showCard("queue");
    }
}
