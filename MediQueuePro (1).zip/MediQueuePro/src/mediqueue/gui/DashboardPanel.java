package mediqueue.gui;

import mediqueue.model.Doctor;
import mediqueue.util.ThemeManager;

import javax.swing.*;
import java.awt.*;

public class DashboardPanel extends JPanel {

    private final MainFrame frame;
    private final JPanel cardsPanel;
    private final JPanel doctorsPanel;

    public DashboardPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(15, 15));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setBackground(ThemeManager.background());

        JLabel header = new JLabel("Dashboard Overview");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        cardsPanel = new JPanel(new GridLayout(1, 4, 15, 15));
        cardsPanel.setOpaque(false);
        cardsPanel.setPreferredSize(new Dimension(100, 120));

        doctorsPanel = new JPanel();
        doctorsPanel.setLayout(new BoxLayout(doctorsPanel, BoxLayout.Y_AXIS));
        doctorsPanel.setBorder(BorderFactory.createTitledBorder("Doctor Availability"));
        doctorsPanel.setBackground(ThemeManager.panelBg());

        JPanel center = new JPanel(new BorderLayout(10, 10));
        center.setOpaque(false);
        center.add(cardsPanel, BorderLayout.NORTH);
        center.add(new JScrollPane(doctorsPanel), BorderLayout.CENTER);

        add(center, BorderLayout.CENTER);
    }

    public void refresh() {
        cardsPanel.removeAll();
        int waiting = frame.getQueueManager().totalWaiting();
        int emergency = frame.getQueueManager().emergencyCount();
        long doctorsAvailable = frame.getDoctors().stream().filter(Doctor::isAvailable).count();
        long totalRegistered = frame.getPatientMap().values().size();

        cardsPanel.add(new StatCard("Waiting Patients", String.valueOf(waiting), ThemeManager.accent()));
        cardsPanel.add(new StatCard("Emergency Cases", String.valueOf(emergency), ThemeManager.danger()));
        cardsPanel.add(new StatCard("Doctors Available", doctorsAvailable + "/" + frame.getDoctors().size(), ThemeManager.success()));
        cardsPanel.add(new StatCard("Total Registered", String.valueOf(totalRegistered), ThemeManager.warning()));

        doctorsPanel.removeAll();
        for (Doctor d : frame.getDoctors()) {
            JLabel lbl = new JLabel((d.isAvailable() ? "\uD83D\uDFE2 " : "\uD83D\uDD34 ") + d.toString());
            lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            lbl.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
            doctorsPanel.add(lbl);
        }
        revalidate();
        repaint();
    }

    static class StatCard extends JPanel {
        private final String title, value;
        private final Color color;

        StatCard(String title, String value, Color color) {
            this.title = title;
            this.value = value;
            this.color = color;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 28));
            g2.drawString(value, 15, 45);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            g2.drawString(title, 15, 70);
        }
    }
}
