package mediqueue.gui;

import javax.swing.*;
import java.awt.*;

public class AboutPanel extends JPanel {

    public AboutPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setText(
                "MediQueue Pro\n" +
                        "Hospital Queue Management System\n\n" +
                        "Version: 1.0\n\n" +
                        "About:\n" +
                        "MediQueue Pro is a desktop application built with Java Swing and AWT that simulates " +
                        "a real-world hospital patient queue management system. It demonstrates core data " +
                        "structures (Queue, Priority Queue, Stack, HashMap, LinkedList), file handling with " +
                        "Java Serialization, custom Java2D graphics, the Java Sound API for notifications, " +
                        "and the Java Printing API for token slips.\n\n" +
                        "Core Concepts Demonstrated:\n" +
                        "- Queue and PriorityQueue for normal/emergency patient handling\n" +
                        "- Stack for undo functionality\n" +
                        "- HashMap for fast patient lookup\n" +
                        "- Object Serialization for offline data persistence\n" +
                        "- Custom Java2D charts and dashboard cards\n" +
                        "- Java Sound API for notification tones\n" +
                        "- Java Printing API for token slip printing\n" +
                        "- Hand-built minimal PDF export (no external libraries)\n\n" +
                        "Developed as an academic classroom project."
        );

        add(new JScrollPane(area), BorderLayout.CENTER);
    }
}
