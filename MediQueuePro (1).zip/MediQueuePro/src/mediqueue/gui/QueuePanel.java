package mediqueue.gui;

import mediqueue.model.Patient;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.List;

public class QueuePanel extends JPanel {

    private final MainFrame frame;
    private final DefaultTableModel model;
    private final JTable table;
    private final JLabel nowServingLabel;

    public QueuePanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel header = new JLabel("Queue Management");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Token", "Name", "Department", "Doctor", "Priority", "Est. Wait (min)"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(26);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());
        nowServingLabel = new JLabel("Now Serving: -");
        nowServingLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        bottom.add(nowServingLabel, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton callNextBtn = new JButton("\u25B6 Call Next Patient");
        JButton skipBtn = new JButton("\u23ED Skip Selected");
        JButton undoBtn = new JButton("\u21A9 Undo Last Call");
        JButton printBtn = new JButton("\uD83D\uDDA8 Print Token");

        callNextBtn.addActionListener(e -> callNext());
        skipBtn.addActionListener(e -> skipSelected());
        undoBtn.addActionListener(e -> undoLast());
        printBtn.addActionListener(e -> printToken());

        buttons.add(callNextBtn);
        buttons.add(skipBtn);
        buttons.add(undoBtn);
        buttons.add(printBtn);
        bottom.add(buttons, BorderLayout.SOUTH);
        add(bottom, BorderLayout.SOUTH);
    }

    public void refresh() {
        model.setRowCount(0);
        int consultMin = Integer.parseInt(frame.getSettings().getProperty("consultationMinutes", "10"));
        List<Patient> waiting = frame.getQueueManager().getAllWaiting();
        for (Patient p : waiting) {
            int wait = frame.getQueueManager().estimateWaitMinutes(p, consultMin);
            model.addRow(new Object[]{p.getToken(), p.getName(), p.getDepartment(), p.getDoctor(), p.getPriority(), wait});
        }
        Patient last = frame.getQueueManager().getLastCalled();
        nowServingLabel.setText("Now Serving: " + (last != null ? "Token #" + last.getToken() + " - " + last.getName() : "-"));
    }

    private void callNext() {
        Patient p = frame.getQueueManager().callNext();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "No patients waiting.", "Queue Empty", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Calling Token #" + p.getToken() + " - " + p.getName(), "Now Serving", JOptionPane.INFORMATION_MESSAGE);
        }
        frame.refreshAll();
    }

    private void skipSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a patient first.");
            return;
        }
        int token = (int) model.getValueAt(row, 0);
        Patient target = findByToken(token);
        if (target != null) frame.getQueueManager().skip(target);
        frame.refreshAll();
    }

    private void undoLast() {
        Patient p = frame.getQueueManager().undoLastCall();
        if (p == null) JOptionPane.showMessageDialog(this, "No call to undo.");
        frame.refreshAll();
    }

    private Patient findByToken(int token) {
        for (Patient p : frame.getPatientMap().values()) {
            if (p.getToken() == token) return p;
        }
        return null;
    }

    private void printToken() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a patient first.");
            return;
        }
        int token = (int) model.getValueAt(row, 0);
        Patient p = findByToken(token);
        if (p == null) return;

        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(new Printable() {
            @Override
            public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
                if (pageIndex > 0) return Printable.NO_SUCH_PAGE;
                Graphics2D g2 = (Graphics2D) graphics;
                g2.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                g2.setFont(new Font("Serif", Font.BOLD, 20));
                g2.drawString("MediQueue Pro - Token Slip", 20, 30);
                g2.setFont(new Font("Serif", Font.PLAIN, 14));
                g2.drawString("Token Number: " + p.getToken(), 20, 70);
                g2.drawString("Patient: " + p.getName(), 20, 95);
                g2.drawString("Department: " + p.getDepartment(), 20, 120);
                g2.drawString("Doctor: " + p.getDoctor(), 20, 145);
                g2.drawString("Priority: " + p.getPriority(), 20, 170);
                g2.drawString("Time: " + p.getRegisteredTimeString(), 20, 195);
                return Printable.PAGE_EXISTS;
            }
        });
        try {
            if (job.printDialog()) job.print();
        } catch (PrinterException ex) {
            JOptionPane.showMessageDialog(this, "Print failed: " + ex.getMessage());
        }
    }
}
