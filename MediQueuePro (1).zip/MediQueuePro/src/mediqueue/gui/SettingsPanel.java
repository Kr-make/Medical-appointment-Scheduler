package mediqueue.gui;

import mediqueue.util.ThemeManager;

import javax.swing.*;
import java.awt.*;

public class SettingsPanel extends JPanel {

    private final MainFrame frame;
    private final JRadioButton lightBtn, darkBtn;
    private final JSpinner consultSpinner;

    public SettingsPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.anchor = GridBagConstraints.WEST;

        JLabel header = new JLabel("Settings");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2; add(header, c);
        c.gridwidth = 1;

        c.gridy = 1; c.gridx = 0; add(new JLabel("Theme:"), c);
        JPanel themePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        lightBtn = new JRadioButton("Light Mode");
        darkBtn = new JRadioButton("Dark Mode");
        ButtonGroup bg = new ButtonGroup();
        bg.add(lightBtn);
        bg.add(darkBtn);
        if (ThemeManager.isDark()) darkBtn.setSelected(true); else lightBtn.setSelected(true);
        themePanel.add(lightBtn);
        themePanel.add(darkBtn);
        c.gridx = 1; add(themePanel, c);

        c.gridy = 2; c.gridx = 0; add(new JLabel("Avg. Consultation Time (minutes):"), c);
        int currentMin = Integer.parseInt(frame.getSettings().getProperty("consultationMinutes", "10"));
        consultSpinner = new JSpinner(new SpinnerNumberModel(currentMin, 1, 60, 1));
        c.gridx = 1; add(consultSpinner, c);

        JButton saveBtn = new JButton("Save Settings");
        saveBtn.setBackground(new Color(41, 128, 185));
        saveBtn.setForeground(Color.WHITE);
        saveBtn.addActionListener(e -> saveSettings());
        c.gridy = 3; c.gridx = 0; c.gridwidth = 2; add(saveBtn, c);
    }

    private void saveSettings() {
        ThemeManager.setDark(darkBtn.isSelected());
        frame.getSettings().setProperty("theme", darkBtn.isSelected() ? "dark" : "light");
        frame.getSettings().setProperty("consultationMinutes", String.valueOf(consultSpinner.getValue()));
        JOptionPane.showMessageDialog(this, "Settings saved. Restart the app for full theme changes to apply.");
        frame.refreshAll();
    }
}
