package mediqueue.gui;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class LoginFrame extends JFrame {

    private JTextField userField;
    private JPasswordField passField;
    private JCheckBox rememberBox;
    private static final String REMEMBER_FILE = "data/remember.txt";

    public LoginFrame() {
        setTitle("MediQueue Pro - Login");
        setSize(420, 540);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel root = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(33, 42, 58), 0, getHeight(), new Color(41, 128, 185));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        root.setLayout(new GridBagLayout());
        setContentPane(root);

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        card.setPreferredSize(new Dimension(320, 420));

        JLabel logo = new JLabel("\uD83C\uDFE5", SwingConstants.CENTER);
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("MediQueue Pro");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Hospital Queue Management System");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        subtitle.setForeground(Color.GRAY);
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        userField = new JTextField("admin");
        passField = new JPasswordField();
        rememberBox = new JCheckBox("Remember me");
        rememberBox.setAlignmentX(Component.CENTER_ALIGNMENT);

        styleField(userField);
        styleField(passField);

        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBackground(new Color(41, 128, 185));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginBtn.setMaximumSize(new Dimension(250, 40));
        loginBtn.addActionListener(e -> attemptLogin());

        JLabel hint = new JLabel("Default: admin / admin123");
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 10));
        hint.setForeground(Color.LIGHT_GRAY);
        hint.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(logo);
        card.add(Box.createVerticalStrut(5));
        card.add(title);
        card.add(subtitle);
        card.add(Box.createVerticalStrut(20));
        card.add(userField);
        card.add(Box.createVerticalStrut(10));
        card.add(passField);
        card.add(Box.createVerticalStrut(5));
        card.add(rememberBox);
        card.add(Box.createVerticalStrut(15));
        card.add(loginBtn);
        card.add(Box.createVerticalStrut(10));
        card.add(hint);

        root.add(card);

        loadRemembered();
        passField.addActionListener(e -> attemptLogin());
    }

    private void styleField(JTextField f) {
        f.setMaximumSize(new Dimension(250, 32));
        f.setAlignmentX(Component.CENTER_ALIGNMENT);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)));
    }

    private void attemptLogin() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());
        if (user.equals("admin") && pass.equals("admin123")) {
            if (rememberBox.isSelected()) saveRemembered(user); else clearRemembered();
            dispose();
            SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveRemembered(String user) {
        try {
            new File("data").mkdirs();
            try (PrintWriter pw = new PrintWriter(new FileWriter(REMEMBER_FILE))) {
                pw.println(user);
            }
        } catch (Exception ignored) {
        }
    }

    private void clearRemembered() {
        new File(REMEMBER_FILE).delete();
    }

    private void loadRemembered() {
        File f = new File(REMEMBER_FILE);
        if (f.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String u = br.readLine();
                if (u != null) {
                    userField.setText(u);
                    rememberBox.setSelected(true);
                }
            } catch (Exception ignored) {
            }
        }
    }
}
