package mediqueue.gui;

import mediqueue.dsa.QueueManager;
import mediqueue.model.Doctor;
import mediqueue.model.Patient;
import mediqueue.util.FileManager;
import mediqueue.util.ThemeManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class MainFrame extends JFrame {

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel contentPanel = new JPanel(cardLayout);
    private final JLabel clockLabel = new JLabel();

    private final QueueManager queueManager = new QueueManager();
    private final Map<String, Patient> patientMap = new HashMap<>();
    private final List<Doctor> doctors;
    private final Properties settings;
    private int tokenCounter = 1;

    private DashboardPanel dashboardPanel;
    private QueuePanel queuePanel;
    private ReportsPanel reportsPanel;

    public MainFrame() {
        setTitle("MediQueue Pro - Hospital Queue Management System");
        setSize(1150, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) { shutdown(); }
        });

        settings = FileManager.loadSettings();
        ThemeManager.setDark("dark".equals(settings.getProperty("theme", "light")));
        doctors = FileManager.loadDoctors();

        List<Patient> loaded = FileManager.loadPatients();
        for (Patient p : loaded) {
            patientMap.put(p.getId(), p);
            if (p.getStatus() == Patient.Status.WAITING) queueManager.enqueue(p);
            if (p.getToken() >= tokenCounter) tokenCounter = p.getToken() + 1;
        }

        setLayout(new BorderLayout());
        add(buildTopBar(), BorderLayout.NORTH);
        add(buildSidebar(), BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);

        dashboardPanel = new DashboardPanel(this);
        queuePanel = new QueuePanel(this);
        reportsPanel = new ReportsPanel(this);

        contentPanel.add(dashboardPanel, "dashboard");
        contentPanel.add(new RegisterPanel(this), "register");
        contentPanel.add(queuePanel, "queue");
        contentPanel.add(new SearchPanel(this), "search");
        contentPanel.add(reportsPanel, "reports");
        contentPanel.add(new SettingsPanel(this), "settings");
        contentPanel.add(new AboutPanel(), "about");

        Timer clockTimer = new Timer(1000, e -> updateClock());
        clockTimer.start();
        updateClock();

        refreshAll();
    }

    private JPanel buildTopBar() {
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(ThemeManager.accent());
        top.setPreferredSize(new Dimension(100, 55));
        top.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));

        JLabel title = new JLabel("\uD83C\uDFE5  MediQueue Pro");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        top.add(title, BorderLayout.WEST);

        clockLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        clockLabel.setForeground(Color.WHITE);
        top.add(clockLabel, BorderLayout.EAST);
        return top;
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(ThemeManager.sidebarBg());
        sidebar.setPreferredSize(new Dimension(210, 100));

        String[][] items = {
                {"dashboard", "\u25A3  Dashboard"},
                {"register", "\u2795  Register Patient"},
                {"queue", "\u2630  Queue Management"},
                {"search", "\uD83D\uDD0D  Search"},
                {"reports", "\uD83D\uDCCA  Reports"},
                {"settings", "\u2699  Settings"},
                {"about", "\u2139  About"}
        };

        sidebar.add(Box.createVerticalStrut(20));
        for (String[] item : items) {
            JButton btn = new JButton(item[1]);
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            btn.setMaximumSize(new Dimension(190, 40));
            btn.setFocusPainted(false);
            btn.setBackground(ThemeManager.sidebarBg());
            btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
            btn.setHorizontalAlignment(SwingConstants.LEFT);
            btn.addActionListener(e -> {
                cardLayout.show(contentPanel, item[0]);
                refreshAll();
            });
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(5));
        }
        sidebar.add(Box.createVerticalGlue());

        JButton logoutBtn = new JButton("\u23FB  Logout");
        logoutBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoutBtn.setMaximumSize(new Dimension(190, 40));
        logoutBtn.setBackground(ThemeManager.danger());
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> {
            shutdown();
            dispose();
            SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
        });
        sidebar.add(logoutBtn);
        sidebar.add(Box.createVerticalStrut(20));

        return sidebar;
    }

    private void updateClock() {
        clockLabel.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy   hh:mm:ss a")));
    }

    public void shutdown() {
        List<Patient> all = new ArrayList<>(patientMap.values());
        FileManager.savePatients(all);
        FileManager.saveDoctors(doctors);
        FileManager.saveSettings(settings);
        System.exit(0);
    }

    public void refreshAll() {
        if (dashboardPanel != null) dashboardPanel.refresh();
        if (queuePanel != null) queuePanel.refresh();
        if (reportsPanel != null) reportsPanel.refresh();
    }

    public QueueManager getQueueManager() { return queueManager; }
    public Map<String, Patient> getPatientMap() { return patientMap; }
    public List<Doctor> getDoctors() { return doctors; }
    public Properties getSettings() { return settings; }
    public int nextToken() { return tokenCounter++; }

    public void showCard(String name) {
        cardLayout.show(contentPanel, name);
        refreshAll();
    }
}
