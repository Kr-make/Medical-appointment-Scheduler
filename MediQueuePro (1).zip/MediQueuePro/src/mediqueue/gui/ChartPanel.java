package mediqueue.gui;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class ChartPanel extends JPanel {

    private Map<String, Long> data = new LinkedHashMap<>();
    private static final Color[] COLORS = {
            new Color(41, 128, 185), new Color(39, 174, 96), new Color(231, 76, 60),
            new Color(243, 156, 18), new Color(155, 89, 182), new Color(26, 188, 156)
    };

    public void setData(Map<String, Long> data) {
        this.data = data;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth(), height = getHeight();
        int margin = 40;
        int chartHeight = height - 2 * margin;
        int chartWidth = width - 2 * margin;

        if (data.isEmpty()) {
            g2.drawString("No data to display yet.", width / 2 - 60, height / 2);
            return;
        }

        long max = data.values().stream().mapToLong(Long::longValue).max().orElse(1);
        int barCount = data.size();
        int barWidth = Math.max(30, chartWidth / (barCount * 2));
        int gap = barWidth;

        int x = margin;
        int i = 0;
        g2.setColor(Color.GRAY);
        g2.drawLine(margin, height - margin, width - margin, height - margin);

        for (Map.Entry<String, Long> e : data.entrySet()) {
            long val = e.getValue();
            int barHeight = (int) (((double) val / max) * (chartHeight - 20));
            int y = height - margin - barHeight;
            g2.setColor(COLORS[i % COLORS.length]);
            g2.fillRoundRect(x, y, barWidth, barHeight, 8, 8);
            g2.setColor(Color.BLACK);
            g2.drawString(String.valueOf(val), x + barWidth / 2 - 5, y - 5);
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            String label = e.getKey().length() > 10 ? e.getKey().substring(0, 10) + "." : e.getKey();
            g2.drawString(label, x, height - margin + 15);
            x += barWidth + gap;
            i++;
        }
    }
}
