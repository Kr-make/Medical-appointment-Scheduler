package mediqueue.gui;

import mediqueue.model.Patient;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SearchPanel extends JPanel {

    private final MainFrame frame;
    private final JTextField searchField;
    private final JComboBox<String> criteriaBox;
    private final DefaultTableModel model;

    public SearchPanel(MainFrame frame) {
        this.frame = frame;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel header = new JLabel("Search Patients");
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        add(header, BorderLayout.NORTH);

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        criteriaBox = new JComboBox<>(new String[]{"ID", "Name", "Department", "Token"});
        searchField = new JTextField(20);
        JButton searchBtn = new JButton("Search");
        searchBtn.addActionListener(e -> doSearch());
        searchField.addActionListener(e -> doSearch());
        top.add(new JLabel("Search by:"));
        top.add(criteriaBox);
        top.add(searchField);
        top.add(searchBtn);

        JPanel center = new JPanel(new BorderLayout());
        center.add(top, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID", "Token", "Name", "Department", "Doctor", "Priority", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        center.add(new JScrollPane(table), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
    }

    private void doSearch() {
        String query = searchField.getText().trim().toLowerCase();
        String criteria = (String) criteriaBox.getSelectedItem();
        model.setRowCount(0);
        List<Patient> results = new ArrayList<>();
        for (Patient p : frame.getPatientMap().values()) {
            boolean match;
            switch (criteria) {
                case "ID":
                    match = p.getId().toLowerCase().contains(query);
                    break;
                case "Name":
                    match = p.getName().toLowerCase().contains(query);
                    break;
                case "Department":
                    match = p.getDepartment().toLowerCase().contains(query);
                    break;
                case "Token":
                    match = String.valueOf(p.getToken()).contains(query);
                    break;
                default:
                    match = false;
            }
            if (query.isEmpty() || match) results.add(p);
        }
        for (Patient p : results) {
            model.addRow(new Object[]{p.getId(), p.getToken(), p.getName(), p.getDepartment(), p.getDoctor(), p.getPriority(), p.getStatus()});
        }
    }
}
